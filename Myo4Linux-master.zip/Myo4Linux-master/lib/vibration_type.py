from enum import Enum

class VibrationType(Enum):
	NONE = 0
	SHORT = 1
	MEDIUM = 2
	LONG = 3